import { Controller, Get, Body} from '@nestjs/common';
import { DownloadAbhaCardPngcardService } from './download_abha_card_pngcard.service';
@Controller('download_abha_card_pngcard')
export class DownloadAbhaCardPngcardController {
  constructor(private readonly cardService: DownloadAbhaCardPngcardService) {}

  @Get('/')
  async getCard(@Body('token') token: string) {
      return await this.cardService.getQrCode(token);
  }
}
