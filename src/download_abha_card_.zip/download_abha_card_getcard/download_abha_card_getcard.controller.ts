import { Controller, Get, Body, Param} from '@nestjs/common';
import { DownloadAbhaCardGetcardService } from './download_abha_card_getcard.service';

@Controller('download_abha_card_getcard')
export class DownloadAbhaCardGetcardController {
  
  constructor(private readonly cardService: DownloadAbhaCardGetcardService) {}

  @Get('/:token')
  async getCard(@Param('token') token: string) {
    console.log(token,'token')
      return await this.cardService.getQrCode(token);
  }
}
