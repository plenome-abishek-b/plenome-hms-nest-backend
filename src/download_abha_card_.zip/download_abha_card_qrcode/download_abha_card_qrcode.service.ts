import { Injectable } from '@nestjs/common';
import axios from 'axios';

@Injectable()
export class DownloadAbhaCardQrcodeService {
  
  constructor() {}

  async getAccessToken() {
      const data = {
        clientId: process.env.CLIENT_ID,
        clientSecret: process.env.CLIENT_SECRET,
        grantType: 'client_credentials',
      };
      const accessTokenUrl = 'https://dev.abdm.gov.in/gateway/v0.5/sessions';
      const response = await axios.post(accessTokenUrl, data);
      return response.data.accessToken;
    }

    async getQrCode(token: string) {
      const accessToken = await this.getAccessToken();
      
      const headers = {
        'accept': '*/*',
        'Connection': 'keep-alive',
        'Accept-Language': 'en-US',
        'Content-Type': 'application/json',
        'X-Token': `Bearer ${token}`,
        'Authorization': `Bearer ${accessToken}`
      };
      console.log(headers, "this is the headers")
      const getQrCodeOTPURL = 'https://healthidsbx.abdm.gov.in/api/v1/account/qrCode';
      const response = await axios.get(getQrCodeOTPURL, { headers });
      return response.data;
    }
}
